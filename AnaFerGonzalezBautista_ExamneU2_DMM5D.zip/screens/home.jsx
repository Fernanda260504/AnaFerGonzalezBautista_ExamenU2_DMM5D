import React, { useState } from 'react';
import { View, ScrollView, StyleSheet, Text, Image, Modal, TouchableOpacity, Dimensions } from 'react-native';
import StoryItem from './storyItem';
import Icon from 'react-native-vector-icons/FontAwesome';
import { FontAwesome5, Ionicons, MaterialIcons } from '@expo/vector-icons';

const Home = () => {
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedStory, setSelectedStory] = useState(null);

  const openModal = (story) => {
    setSelectedStory(story);
    setModalVisible(true);
  };

  const closeModal = () => {
    setSelectedStory(null);
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      <ScrollView horizontal style={styles.horizontalScrollView}>
        <TouchableOpacity onPress={() => openModal({ username: 'kaarl', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Caf%C3%A9_con_Mezcal_con_KEVIN_KAARL%21_%28CROPPED%29.png' })}>
          <StoryItem username="kaarl" imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => openModal({ username: 'kevin_kaarl', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Caf%C3%A9_con_Mezcal_con_KEVIN_KAARL%21_%28CROPPED%29.png' })}>
          <StoryItem username="kevin_kaarl" imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => openModal({ username: 'kevin_kaarl', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Caf%C3%A9_con_Mezcal_con_KEVIN_KAARL%21_%28CROPPED%29.png' })}>
          <StoryItem username="monlaferte" imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => openModal({ username: 'lana_rey', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Caf%C3%A9_con_Mezcal_con_KEVIN_KAARL%21_%28CROPPED%29.png' })}>
          <StoryItem username="lana_rey" imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => openModal({ username: 'kenin_1', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Caf%C3%A9_con_Mezcal_con_KEVIN_KAARL%21_%28CROPPED%29.png' })}>
          <StoryItem username="kenin_1" imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        </TouchableOpacity>
        <TouchableOpacity onPress={() => openModal({ username: 'hoi_1', imageUrl: 'https://upload.wikimedia.org/wikipedia/commons/b/bf/Caf%C3%A9_con_Mezcal_con_KEVIN_KAARL%21_%28CROPPED%29.png' })}>
          <StoryItem username="hoi_1" imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        </TouchableOpacity>
      </ScrollView>

      <ScrollView style={styles.verticalScrollView}>
        <View style={styles.header}>
          <Image style={styles.imagen} source={require('../assets/Kevin.jpg')} />
          <Text style={styles.text}>Kevin Kaarl</Text>
          <Icon name="ellipsis-v" size={20} color="#000" style={{ marginRight: 100 }} />
        </View>
        <View style={styles.imageContainer}>
          <Image style={styles.imagen2} source={{ uri: 'https://storage.googleapis.com/pr-newsroom-wp/1/2022/10/singles-kevin-kaarl-cover-scaled.jpg' }} />
          <View style={styles.iconsContainer}>
            <FontAwesome5 name="heart" size={24} color="black" style={styles.icon} />
            <MaterialIcons name="send" size={24} color="black" style={styles.icon} />
            <Icon name="bookmark" size={24} color="black" style={styles.icon}  />
          </View>
          <View style={styles.container}>
            <Text style={{ marginLeft: -190 }}>4,540 Me gusta</Text>
            <Text style={{ marginLeft: -190 }}>Los Amoooo,Gracias por todo</Text>
          </View>
        </View>
        <View style={styles.header}>
        <Image style={styles.imagen} source={require('../assets/ed.jpeg')} />
        <Text style={styles.text}>Ed Maverick</Text>
        <Icon name="ellipsis-v" size={20} color="#000" style={{ marginRight: 100 }} />
      </View>
        <View style={styles.imageContainer}>
        <Image style={styles.imagen2} source={{ uri: 'https://i.pinimg.com/736x/d9/0d/9c/d90d9c06f7d2f37ae88746de02657362.jpg' }} />
        <View style={styles.iconsContainer}>
          <FontAwesome5 name="heart" size={24} color="black" style={styles.icon} />
          <MaterialIcons name="send" size={24} color="black" style={styles.icon} />
          <Icon name="bookmark" size={24} color="black" style={styles.icon}  />
        </View>
        <View style={styles.container}>
          <Text style={{ marginLeft: -190 }}>4,546 Me gusta</Text>
          <Text style={{ marginLeft: -190 }}>¡Bienvenido Karma!</Text>
        </View>
      </View>

      <View style={styles.header}>
        <Image style={styles.imagen} source={require('../assets/ldr.jpeg')} />
        <Text style={styles.text}>Lana del Rey</Text>
        <Icon name="ellipsis-v" size={20} color="#000" style={{ marginRight: 100 }} />
      </View>
      <View style={styles.imageContainer}>
        <Image style={styles.imagen2} source={{ uri: 'https://hips.hearstapps.com/hmg-prod/images/lana-del-rey-attends-the-60th-annual-grammy-awards-at-madison-square-garden-on-january-28-2018-in-new-york-city-photo-by-dimitrios-kambouris_getty-images-for-naras-square.jpg' }} />
        <View style={styles.iconsContainer}>
          <FontAwesome5 name="heart" size={24} color="black" style={styles.icon} />
          <MaterialIcons name="send" size={24} color="black" style={styles.icon} />
          <Icon name="bookmark" size={24} color="black" style={styles.icon}  />
        </View>
        <View style={styles.container}>
          <Text style={{ marginLeft: -190 }}>4,546 Me gusta</Text>
          <Text style={{ marginLeft: -190 }}>Lana del What?</Text>
        </View>
        </View>



        

      </ScrollView>

      <Modal
        animationType="slide"
        transparent={true}
        visible={modalVisible}
        onRequestClose={closeModal}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
             {selectedStory && (
              <>
              <View style={styles.header}>
           


               
              </View>
              <Image style={styles.imgModal} source={{ uri: selectedStory.imageUrl }} />
             
              </>
            )}
            <TouchableOpacity style={styles.cerrarModal} onPress={closeModal}>
             
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  horizontalScrollView: {
    marginTop:5,
    height:120
  
  },
  verticalScrollView: {
    paddingVertical: 10,
  },
  header: {
    width: '100%',
    height: 50,
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  imagen: {
    width: 50,
    height: 50,
    borderRadius: 70,
    marginRight: 10,
  },
  text: {
    textAlign: 'left',
    marginRight: 250,
  },
  imageContainer: {
    marginTop: 10,
    alignItems: 'center',
  },
  imagen2: {
    width: 370,
    height: 370,
  },
  iconsContainer: {
    flexDirection: 'row',
    marginTop: 10,
    marginLeft: -290 
  },
  icon: {
    marginRight: 10, 
  },
  modalContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
  },
  modalContent: {
    backgroundColor: 'white',
    borderRadius: 20,
    shadowColor: '#000',
    justifyContent: 'flex-start',
    alignItems: 'flex-start',
    width: '100%',
    height: '100%',
    padding: 20,
  },
  imgModal: {
    height: 600,
    width: 370,
    justifyContent: 'center',
    alignItems: 'center',
    marginTop:2
  },
  modalText: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'left',
    marginRight: 270,
    marginBottom: 20,
    color: 'black',
  },
});

export default Home;
