import { StyleSheet, Text, View, Image, Modal, Alert, TextInput, TouchableOpacity , ScrollView} from 'react-native';
import StoryItem from './storyItem';
Perfil = ()=>{

    return(
        <View style={styles.container}>
        <View style={styles.header}>
        <Image style={styles.imagen} source={require('../assets/viaje.jpg')} />
        <View  style={{flexDirection:"row",marginHorizontal:10}}>
            <View style={{marginLeft:-20,justifyContent:'center',flexDirection:'row'}}>
            <Text style={{marginHorizontal:20,marginTop:2,padding:5}}>9</Text>
            </View>
            <Text style={{marginHorizontal:60,padding:5}}>456</Text>
            <Text >901</Text>
            </View>
       
       

      <View style={{flexDirection:'row',marginTop:20,marginLeft:-200}}>
       
        <Text style={{paddingBottom:-3,marginLeft:-20,padding:-70,flexDirection:'column',marginHorizontal:30}}>Publicaciones</Text>

        <Text style={{paddingBottom:-3,marginTop:-1,marginLeft:-20,padding:-20,flexDirection:'column',marginHorizontal:70}} >Seguidos</Text>
        <Text style={{paddingBottom:-3,marginTop:-1,marginLeft:-20,padding:-20,flexDirection:'column',marginHorizontal:5}}>Seguidores</Text>

        </View>
        
   
      </View>

      <View>
            
        <ScrollView horizontal style={styles.horizontalScrollView}>
        
       
          <StoryItem imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
        
       
          <StoryItem imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
       
        
          <StoryItem imageUrl="https://elcomercio.pe/resizer/8rkkeLi2MTi4_C19_tVs9ZIOdGk=/1200x1200/smart/filters:format(jpeg):quality(75)/cloudfront-us-east-1.images.arcpublishing.com/elcomercio/JIMHMGEFDJDCPFBFPFIW5SZNVY.jpg" />
       
      
        
      </ScrollView>


      <View>

      <Image style={styles.image} source={require('../assets/perro.jpg')}/><Image style={styles.image} source={require('../assets/perro.jpg')}/>
      <Image style={styles.image} source={require('../assets/perro.jpg')}/>
      <Image style={styles.image} source={require('../assets/perro.jpg')}/>

      </View>
      

     
       
      </View>
      
      </View>
      

    );
}

export default Perfil;

const styles = StyleSheet.create({
    container:{
        textAlignVertical:'center'

    },


    header: {
        width: '100%',
        height: 50,
        display: 'flex',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent: 'space-between',
      },
      imagen: {
        width: 80,
        height: 80,
        borderRadius: 70,
        marginRight: 10,
        marginTop:50
      },
      text:{
     
    
     alignContent:'flex-start',
     textAlign:'left'
     
      },
      usuario:{
      justifyContent:'center',
      flex:1,
      alignItems:'center',
      flexDirection: 'row',
      
  

      },
      horizontalScrollView: {
        marginTop:90,
        height:120
      
      },
      image:{
        width:120,
        height:120,
        borderRadius:5,
      }
});