import React from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';

const StoryItem = ({ username, imageUrl, hasStory }) => {
  return (
    <View style={styles.container}>
      <View style={[styles.imageContainer, hasStory && styles.hasStory]}>
        <Image source={{ uri: imageUrl }} style={styles.image} />
      </View>
      <Text style={styles.username}>{username}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    marginRight: 10,
  },
  imageContainer: {
    width: 74,
    height: 74,
    borderRadius: 37,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#DD2A7B', 
  },
  image: {
    width: 70,
    height: 70,
    borderRadius: 35,
  },
  hasStory: {
    borderColor: '#4CAF50', 
  },
  username: {
    marginTop: 5,
  },
});

export default StoryItem;
