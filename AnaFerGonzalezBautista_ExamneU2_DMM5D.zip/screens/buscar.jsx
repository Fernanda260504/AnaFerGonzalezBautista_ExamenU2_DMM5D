
import { StyleSheet, Text, View, Image, Modal, Alert, TextInput } from 'react-native';
import Icon from 'react-native-vector-icons/FontAwesome';
Buscar = ()=>{

    return(
        <View style={styles.container}>
       
        <TextInput style={styles.input} />

            <View>

      <Image style={styles.image} source={require('../assets/perro.jpg')}/>
      <Image style={styles.image} source={require('../assets/perro.jpg')}/>
      <Image style={styles.image} source={require('../assets/perro.jpg')}/>

      </View>
        </View>
    );
}

export default Buscar;

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#f2f2f200',
      alignItems: 'center',
      justifyContent: 'center',
    },
    textInput :{
        fontSize: 15, marginBottom: 20 ,backgroundColor:'black'
    },
    image:{
        width:120,
        height:120,
        borderRadius:5,
      },
      input: {
        margin:-200,
        marginBottom: 10, 
        backgroundColor: "#FFFFFF",
        borderColor: "black", 
        borderWidth: 1,
        width: 250,
        marginLeft: -150,
        borderRadius: 5,
        
        height:40,
    
    
      },
});