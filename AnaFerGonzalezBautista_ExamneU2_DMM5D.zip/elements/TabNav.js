import Icon from 'react-native-vector-icons/FontAwesome';
import { Image } from 'react-native';
import Home from '../screens/home';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import Perfil from '../screens/perfil';
import Buscar from '../screens/buscar';
const Tab = createBottomTabNavigator();

const TabNav = () => {
    return (
        <Tab.Navigator initialRouteName='Home'>
            <Tab.Screen name='Home' component={Home} options={
                {
                    headerShadowVisible: false,
                    tabBarActiveTintColor: '#00aa83',
                    tabBarInactiveTintColor: '#9b9b9b',
                    tabBarIcon: () => (
                        <Icon name="home" size={30} color="#000" />
                    )

                }
            }></Tab.Screen>
            <Tab.Screen name='Buscar' component={Buscar} options={
                {
                    headerShadowVisible: false,
                    tabBarActiveTintColor: '#00aa83',
                    tabBarInactiveTintColor: '#9b9b9b',
                    tabBarIcon: () => (
                        <Icon name="search" size={30} color="#000" />
                    )
                }
            }></Tab.Screen>


            
            <Tab.Screen
                name='Perfil'
                component={Perfil}
                options={{
                    headerShadowVisible: false,
                    tabBarActiveTintColor: '#00aa83',
                    tabBarInactiveTintColor: '#9b9b9b',
                    tabBarIcon: ({ color, size }) => (
                        <Image
                            source={require('../assets/viaje.jpg')}
                            style={{ width: 30, height: 30, borderRadius: 40 }}
                        />
                    )
                }}
            />


        </Tab.Navigator>

    );
}

export default TabNav;