import { NavigationContainer } from "@react-navigation/native";

import { createNativeStackNavigator } from '@react-navigation/native-stack';

import TabNav from "./elements/TabNav";


const Stack = createNativeStackNavigator();
App = () => {
  
  return (
   
    <NavigationContainer>
     <TabNav/>
    </NavigationContainer>
 
  ); 
  
}

export default App;